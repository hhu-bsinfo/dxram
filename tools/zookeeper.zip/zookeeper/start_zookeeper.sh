#!/bin/bash
dataDir=./zookeeper/zooData

DATADIRECOTRY="./zookeeper/zooData";
if [ -d "$DATADIRECOTRY" ]; then
	rm -r ./zookeeper/zooData/*;
fi
./zookeeper/bin/zkEnv.sh
./zookeeper/bin/zkServer.sh start
./zookeeper/bin/zkCli.sh